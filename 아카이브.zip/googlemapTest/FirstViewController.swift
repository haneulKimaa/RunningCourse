//
//  FirstViewController.swift
//  googlemapTest
//
//  Created by 김하늘 on 2021/01/30.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let formatter = DateFormatter()
        let formatter2 = DateFormatter()
        formatter.dateFormat = "eeee, MMMM dd, yyyy"
        formatter2.dateFormat = "hh:mm a"
    
        
        let current_date_string = formatter.string(from: Date())
        let current_time_string = formatter2.string(from: Date())
        print(current_date_string)
        print(current_time_string)
        
        
        dayLabel.text = current_date_string
        timeLabel.text = current_time_string
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
