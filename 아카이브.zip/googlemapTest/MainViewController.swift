//
//  MainViewController.swift
//  googlemapTest
//
//  Created by 김하늘 on 2020/10/26.
//

import UIKit
import GoogleMaps
import CoreMotion

class MainViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate {
    
    let mapVC = ViewController()
    let locationManager = CLLocationManager()
    var makerPosition : CGPoint!
    var timer = Timer()
    var line = [0.0, 0.0]
    let pedometer = CMPedometer()
    let activityManager = CMMotionActivityManager()
    var timeCount = 0
    var weight = 60.0
    var met = 0.0

    
    @IBOutlet weak var longtitudeLabel: UILabel!
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var googlemap: UIView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var decimalSecLabel: UILabel!
    @IBOutlet weak var calorieLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        addChild(mapVC)
        mapVC.view.frame = googlemap.bounds
        self.view.addSubview(mapVC.view)
        line = [1.0, 1.0]
        print("line = \(line[0])")
//      임시 처리기
//        if CMPedometer.isStepCountingAvailable() {
//            let calendar = Calendar.current
//            pedometer.queryPedometerData(from: calendar.startOfDay(for: Date()), to: Date()) { (data, error) in
//                print(data)
//            }
//        }
        
        //print(ad.longtitudeNow)
        // Do any additional setup after loading the view.
    }
   
    
    @IBAction func startButton(_ sender: UIButton) {
        mapVC.makeMarker(at: locationManager.location!.coordinate)
        makePointForPolyline()
        
        //걸음 수 표시
        if CMPedometer.isStepCountingAvailable(){
            self.pedometer.startUpdates(from: Date()){ (data, error) in
                if error == nil{
                    if let response = data {
                        DispatchQueue.main.async {
                            print("Step Counter : \(response.numberOfSteps)")
                            self.longtitudeLabel.text = "\(response.numberOfSteps)"
                        }
                    }
                }
            }
        }
        
        //상태 표시(임시)
        if CMMotionActivityManager.isActivityAvailable(){
            self.activityManager.startActivityUpdates(to: OperationQueue.main){ (data) in
                DispatchQueue.main.async {
                    if let activity = data{
                        if activity.running == true{
                            print("running")
                        }
                        else if activity.walking == true{
                            print("walking")
                        }
                        else if activity.automotive == true{
                            print("automative")
                        }
                    }
                }
                
            }
        }
        //타이머 표시
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (_) in
            self.timeCount += 1
            DispatchQueue.main.async {
                let timeString = self.makeTimeLabel(count: self.timeCount)
                self.timeLabel.text = timeString.0
                self.decimalSecLabel.text = ".\(timeString.1)"
                //guard let empty = timeString.0 else {return}
                //self.met = 3.3 * 3.5 * self.weight * Double(timeString.0)
                self.calorieLabel.text = "\(self.met)"
            }
        })
        
    }
    @IBAction func endButton(_ sender: UIButton) {
        mapVC.makeEndMarker(at: locationManager.location!.coordinate)
        timer.invalidate()
        
    }
    @IBAction func makePoint(_ sender: UIButton) {
        mapVC.makePointMarker(at: locationManager.location!.coordinate)
        
    }
    func makePointForPolyline() {
        //3초에 한번 마커 생성
        timer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(makePoint(_:)), userInfo: nil, repeats: true)
        
    }
    func makeTimeLabel(count:Int) -> (String,String) { //return - (TimeLabel, decimalLabel)
        let decimalSec = count % 10
        let sec = (count / 10) % 60
        let min = (count / 10) / 60
        let sec_string = "\(sec)".count == 1 ? "0\(sec)" : "\(sec)"
        let min_string = "\(min)".count == 1 ? "0\(min)" : "\(min)"
        
        return ("\(min_string):\(sec_string)","\(decimalSec)") }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

