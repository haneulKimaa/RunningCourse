//
//  ViewController.swift
//  googlemapTest
//
//  Created by 김하늘 on 2020/10/25.
//

import UIKit
import GoogleMaps

class ViewController: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate {

    var mapView: GMSMapView!
    var marker = GMSMarker()
    var marker2 = GMSMarker()
    let locationManager = CLLocationManager()
    let geocoder = GMSGeocoder()
    var arr: [CLLocationCoordinate2D] = Array()
    var i = 0
    let path = GMSMutablePath()
    

    @IBOutlet weak var smallMapView: GMSMapView!
    
    //let mainVC = MainViewController()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //locationManager.pausesLocationUpdatesAutomatically = false
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        print("1")
        locationManager.delegate = self
        print("2")
        locationManager.requestAlwaysAuthorization()
        print("3")
        locationManager.startUpdatingLocation()
        print("4")
        
    }
    //https://sesang06.tistory.com/175
    //위치 항상허용 업데이트 정보
    @objc func sceneDidEnterBackground(_scene:UIScene){
        locationManager.allowsBackgroundLocationUpdates = true
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        print("oh")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(sceneDidEnterBackground(_scene:)), name: UIApplication.willResignActiveNotification, object: nil)
        mapView = GMSMapView()
        //smallMapView = GMSMapView()
        mapView.isMyLocationEnabled = true
      
        move(at: locationManager.location?.coordinate)
        mapView.settings.myLocationButton = true
        mapView.settings.zoomGestures = true
        mapView.settings.scrollGestures = true
        
        
        
        //mainVC.latitudeLabel.text = "\(latitude)"
        //mainVC.longtitudeLabel.text = "\(longtitude)"
        
        //smallMapView = mapView
        //3초에 delay후 마커 생성
        let time = DispatchTime.now() + .seconds(3)
        DispatchQueue.main.asyncAfter(deadline: time) {
            self.makeMarker(at: self.locationManager.location!.coordinate)
        }
        
        
        self.view = mapView
        //let path = GMSMutablePath()
       // path.addLatitude((locationManager.location?.coordinate.latitude)!, longitude: (locationManager.location?.coordinate.longitude)!)
        //path.addLatitude(37.5141, longitude: 126.9417)
       // let polyline = GMSPolyline(path: path)
       // polyline.strokeWidth = 10.0
        //polyline.geodesic = true
        //polyline.map = self.mapView
       
        
    
        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
            print("이동2")
        }
    func move(at coordinate: CLLocationCoordinate2D?){
        guard let coordinate = coordinate else {
            return
        }
        print("move = \(coordinate)")
        let latitude = coordinate.latitude
        let longtitude = coordinate.longitude
    
        let camera = GMSCameraPosition.camera(withLatitude: latitude, longitude: longtitude, zoom: 16.0)
        mapView.camera = camera
        //latitudeNow = latitude
        //longtitudeNow = longtitude
        
        //mainVC.longtitudeHere = longtitudeNow
        //처리 늦어져 오류생성
        self.view = mapView
        
    }
    func makeMarker(at coordinate: CLLocationCoordinate2D){
        let latitude = coordinate.latitude
        let longtitude = coordinate.longitude
        marker.position = CLLocationCoordinate2D(latitude: latitude, longitude: longtitude)
        marker.appearAnimation = GMSMarkerAnimation.pop
        
        marker.title = "My Position"
        marker.snippet = "Known"
        marker.map = mapView
        
    }
    func makeEndMarker(at coordinate: CLLocationCoordinate2D){
        let latitude = coordinate.latitude
        let longtitude = coordinate.longitude
        marker2.position = CLLocationCoordinate2D(latitude: latitude, longitude: longtitude)
        
        marker2.title = "My Position"
        marker2.snippet = "Known"
        marker2.map = mapView
    }
    @objc func makePointMarker(at coordinate: CLLocationCoordinate2D){
//        let point = GMSMarker()
        let latitude = coordinate.latitude
        let longtitude = coordinate.longitude
//        point.position = CLLocationCoordinate2D(latitude: latitude, longitude: longtitude)
//        point.map = mapView
        arr.append(CLLocationCoordinate2D(latitude: latitude, longitude: longtitude))
        print("cllocationcoordidate2D array\(i) = \(arr[i])")
        path.addLatitude(arr[i].latitude, longitude: arr[i].longitude)
        i = i + 1
        let polyline = GMSPolyline(path: path)
        polyline.strokeWidth = 5.0
        polyline.strokeColor = UIColor.colorWithRGBHex(hex: 0x00A89C)
        polyline.map = mapView
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let firstLocation = locations.first else {
            return
        }
        move(at: firstLocation.coordinate)
        //makeLongtitudeLatitude(at: firstLocation.coordinate)
    }
    //중심점을 이동시켰을 때 카메라 이동 활성화
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool){
        mapView.clear()
        
    }
}
extension UIColor {
    class func colorWithRGBHex(hex: Int, alpha: Float = 1.0) -> UIColor {
        let r = Float((hex >> 16) & 0xFF)
        let g = Float((hex >> 8) & 0xFF)
        let b = Float((hex) & 0xFF)
        
        return UIColor(red: CGFloat(r / 255.0), green: CGFloat(g / 255.0), blue:CGFloat(b / 255.0), alpha: CGFloat(alpha))
    }
}

